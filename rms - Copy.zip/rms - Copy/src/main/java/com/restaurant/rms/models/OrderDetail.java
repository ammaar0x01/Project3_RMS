///*
// * Developer: Ammaar
// * Started: 22.04.25
// * Updated: 05.06.25
//*/
//
//package com.restaurant.rms.models;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.JoinTable;
//import jakarta.persistence.ManyToOne;
//import jakarta.persistence.Table;
//
////@Entity // ?
////@Table(name="OrderDetail")
//public class OrderDetail {
//    // composite PK
//    // orderId, menuItemId
//
//    private int quantity;
//    private double subtotal;
//
////    @ManyToOne
////    @JoinTable(name="Order")
//
//
//    public OrderDetail(){}
//    // ---------------------------------------
//}
