package com.restaurant.rms.controllers;

public class OrderDetailController {

}
