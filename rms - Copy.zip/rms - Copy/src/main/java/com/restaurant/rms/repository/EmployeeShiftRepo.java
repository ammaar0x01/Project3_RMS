package com.restaurant.rms.repository;

import com.restaurant.rms.models.EmployeeShift;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeShiftRepo extends JpaRepository<EmployeeShift, Integer>{
}
